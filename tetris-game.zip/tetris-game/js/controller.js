var eventTouchstart    = "MSPointerDown";
var eventTouchmove     = "MSPointerMove";
var eventTouchend      = "MSPointerUp";

document.body.onkeydown = function( e ) {
    var keys = {
        37: 'left',
        39: 'right',
        40: 'down',
        38: 'rotate',
        32: 'drop'
    };
    if ( typeof keys[ e.keyCode ] != 'undefined' ) {
        keyPress( keys[ e.keyCode ] );
        render();
    }
};

if (window.navigator.msPointerEnabled) {
    //Internet Explorer 10 style
    eventTouchstart    = "MSPointerDown";
    eventTouchmove     = "MSPointerMove";
    eventTouchend      = "MSPointerUp";
} else {
    eventTouchstart    = "touchstart";
    eventTouchmove     = "touchmove";
    eventTouchend      = "touchend";
}

// Respond to swipe events
var touchStartClientX, touchStartClientY;
var gameContainer = document.getElementById("tetris");

gameContainer.addEventListener(eventTouchstart, function (event) {
    if ((!window.navigator.msPointerEnabled && event.touches.length > 1) ||
        event.targetTouches.length > 1) {
        return; // Ignore if touching with more than 1 finger
    }

    if (window.navigator.msPointerEnabled) {
        touchStartClientX = event.pageX;
        touchStartClientY = event.pageY;
    } else {
        touchStartClientX = event.touches[0].clientX;
        touchStartClientY = event.touches[0].clientY;
    }

    event.preventDefault();
});

gameContainer.addEventListener(eventTouchmove, function (event) {
    
    event.preventDefault();
});

gameContainer.addEventListener(eventTouchend, function (event) {
    if ((!window.navigator.msPointerEnabled && event.touches.length > 0) ||
        event.targetTouches.length > 0) {
        return; // Ignore if still touching with one or more fingers
    }

    var touchEndClientX, touchEndClientY;

    if (window.navigator.msPointerEnabled) {
        touchEndClientX = event.pageX;
        touchEndClientY = event.pageY;
    } else {
        touchEndClientX = event.changedTouches[0].clientX;
        touchEndClientY = event.changedTouches[0].clientY;
    }

    var dx = touchEndClientX - touchStartClientX;
    var absDx = Math.abs(dx);

    var dy = touchEndClientY - touchStartClientY;
    var absDy = Math.abs(dy);

    if (Math.max(absDx, absDy) > 10) {
        // (right : left) : (down : up)
        move(absDx > absDy ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0));
    } else {
        if (window.screen.width >= 1000) {
            if (touchEndClientX > 355) {
                move(1);
            } else {
                move(3);
            }
        }
        else{
            if (touchEndClientX > window.screen.width/2) {
                move(1);
            } else {
                move(3);
            }
        }
    }
    
});

