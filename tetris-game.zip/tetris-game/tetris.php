<link href="<?php echo base_url(); ?>assets/css/games/tetris.css?v=<?php echo rand();?>" rel="stylesheet" type="text/css" />
<div class="container">
    <section class="content">
        <div class="row">
            <div class="col-lg-8">
                
                <div class="card" >
                    <div class="card-header">
                        <a href="<?php echo site_url('../game') ?>"><?php echo $this->lang->line('layout_games'); ?></a> > <strong>Xếp hình</strong>
                    </div> 

                    <span id="score-span">Score: <strong id="score">0</strong> - Level: <strong id="level">0</strong></span>

                    <canvas id="tetris" width='300' height='450'></canvas>

                    <table id="suggestion-shape">
                        <tr>
                            <td></td><td></td><td></td><td></td>
                        </tr>
                        <tr>
                            <td></td><td></td><td></td><td></td>
                        </tr>
                        <tr>
                            <td></td><td></td><td></td><td></td>
                        </tr>
                        <tr>
                            <td></td><td></td><td></td><td></td>
                        </tr>
                    </table>

                    <button id="playbutton" alt="Click to play" title="Click to play" onclick="playButtonClicked();"><div class="triangle-right"></div></button>

                    <ul id="guideline">
                        <li>Tap LEFT/RIGHT of screen to move</li>
                        <li>Swipe UP to rotate</li>
                        <li>Swipe DOWN to drop</li>
                    </ul>
                    <ul id="guideline-pc">
                        <li>Press arrow LEFT/RIGHT to move</li>
                        <li>Press arrow UP to rotate</li>
                        <li>Press space-bar to drop</li>
                    </ul>

                </div>
                
            </div><!-- ./col -->
            
            <div class="col-lg-4">
                <!--advertisement-->
                <?php $this->view('templates/game_ads_right'); ?>
            </div><!-- ./col -->
        </div>
    </section>
</div>

<script src="<?php echo base_url(); ?>assets/js/games/tetris/tetris.js?v=<?php echo rand();?>"></script>
<script src="<?php echo base_url(); ?>assets/js/games/tetris/controller.js?v=<?php echo rand();?>"></script>
<script src="<?php echo base_url(); ?>assets/js/games/tetris/render.js?v=<?php echo rand();?>"></script>