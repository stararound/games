var COLS = 10, ROWS = 15;
var board = [];
var lose;
var interval;
var intervalRender;
var current; // current moving shape
var currentX, currentY; // position of current shape
var freezed; // is current shape settled on the board?
var score = 0;
var level = 0;
var idShape = 0;
var idShapeSuggest = -1;
var shapes = [
    [
        [ 0, 0, 0, 0 ],
        [ 1, 1, 1, 1 ],
        [ 0, 0, 0, 0 ],
        [ 0, 0, 0, 0 ]
    ],
    [
        [ 0, 0, 0, 0 ],
        [ 1, 1, 1, 0 ],
        [ 1, 0, 0, 0 ],
        [ 0, 0, 0, 0 ]
    ],
    [
        [ 0, 0, 0, 0 ],
        [ 1, 1, 1, 0 ],
        [ 0, 0, 1, 0 ],
        [ 0, 0, 0, 0 ]
    ],
    [
        [ 0, 0, 0, 0 ],
        [ 0, 1, 1, 0 ],
        [ 0, 1, 1, 0 ],
        [ 0, 0, 0, 0 ]
    ],
    [
        [ 0, 0, 0, 0 ],
        [ 1, 1, 0, 0 ],
        [ 0, 1, 1, 0 ],
        [ 0, 0, 0, 0 ]
    ],
    [
        [ 0, 0, 0, 0 ],
        [ 0, 1, 1, 0 ],
        [ 1, 1, 0, 0 ],
        [ 0, 0, 0, 0 ]
    ],
    [
        [ 0, 0, 0, 0 ],
        [ 0, 1, 0, 0 ],
        [ 1, 1, 1, 0 ],
        [ 0, 0, 0, 0 ]
    ]
];
var colors = [
    'gray', 'lightcoral', 'blue', 'magenta', 'red', 'green', 'purple'
];


// creates a new 4x4 shape in global variable 'current'
// 4x4 so as to cover the size when the shape is rotated
function newShape() {
    idShape = idShapeSuggest >= 0 ? idShapeSuggest : idShape;
    var shape = shapes[ idShape ]; // maintain id for color filling
    
    current = [];
    for ( var y = 0; y < 4; ++y ) {
        current[ y ] = [];
        for ( var x = 0; x < 4; ++x ) {
            if ( shape[y][x] ) {
                current[ y ][ x ] = idShape + 1;
            }
            else {
                current[ y ][ x ] = 0;
            }
        }
    }
    
    // new shape starts to move
    freezed = false;
    // position where the shape will evolve
    currentX = 4;
    currentY = -1;
    // draw suggestion shape
    suggestion();
}

function suggestion() {
    idShapeSuggest = Math.floor( Math.random() * shapes.length );
    var shape = shapes[ idShapeSuggest ]; // maintain id for color filling
    var suggestionShape = document.querySelectorAll("#suggestion-shape tr");
    
    for ( var y = 0; y < 4; ++y ) {
        for ( var x = 0; x < 4; ++x ) {
            if ( shape[y][x] ) {
                suggestionShape[y].querySelector("td:nth-child("+(x+1)+")").style.backgroundColor = colors[ idShapeSuggest ];
            }
            else {
                suggestionShape[y].querySelector("td:nth-child("+(x+1)+")").style.backgroundColor = "#f7f7f7";
            }
        }
    }
}

// clears the board
function init() {
	score = 0;
	level = 0;
	document.getElementById( 'score' ).innerHTML = '' + score;
    for ( var y = 0; y < ROWS; ++y ) {
        board[ y ] = [];
        for ( var x = 0; x < COLS; ++x ) {
            board[ y ][ x ] = 0;
        }
    }
}

// keep the element moving down, creating new shapes and clearing lines
function tick() {
    if ( valid( 0, 1 ) ) {
        ++currentY;
    }
    // if the element settled
    else {
        freeze();
        valid(0, 1);
        clearLines();
        if (lose) {
            clearAllIntervals();
            return false;
        }
        newShape();
    }
}

// stop shape at its position and fix it to board
function freeze() {
    for ( var y = 0; y < 4; ++y ) {
        for ( var x = 0; x < 4; ++x ) {
            if ( current[ y ][ x ] ) {
                board[ y + currentY ][ x + currentX ] = current[ y ][ x ];
            }
        }
    }
    freezed = true;
}

// returns rotates the rotated shape 'current' perpendicularly anticlockwise
function rotate( current ) {
    var newCurrent = [];
    for ( var y = 0; y < 4; ++y ) {
        newCurrent[ y ] = [];
        for ( var x = 0; x < 4; ++x ) {
            newCurrent[ y ][ x ] = current[ 3 - x ][ y ];
        }
    }

    return newCurrent;
}

// check if any lines are filled and clear them
function clearLines() {
	var count = 0;
    for ( var y = ROWS - 1; y >= 0; --y ) {
        var rowFilled = true;
        for ( var x = 0; x < COLS; ++x ) {
            if ( board[ y ][ x ] == 0 ) {
                rowFilled = false;
                break;
            }
        }
        if ( rowFilled ) {
            //document.getElementById( 'clearsound' ).play();
            for ( var yy = y; yy > 0; --yy ) {
                for ( var x = 0; x < COLS; ++x ) {
                    board[ yy ][ x ] = board[ yy - 1 ][ x ];
                }
            }
            ++y;
			count++;
			score += count*10;
			level = Math.floor(score/100);
        }
    }
	document.getElementById( 'score' ).innerHTML = '' + score;
	document.getElementById( 'level' ).innerHTML = '' + level;
}

function keyPress( key ) {
    switch ( key ) {
        case 'left':
            if ( valid( -1 ) ) {
                --currentX;
            }
            break;
        case 'right':
            if ( valid( 1 ) ) {
                ++currentX;
            }
            break;
        case 'down':
            if ( valid( 0, 1 ) ) {
                ++currentY;
            }
            break;
        case 'rotate':
            if (idShape == 3) break;
            var rotated = rotate( current );
            if ( valid( 0, 0, rotated ) ) {
                current = rotated;
            }
            break;
        case 'drop':
            while( valid(0, 1) ) {
                ++currentY;
            }
            tick();
            break;
    }
}

function goLeft() {
    if ( valid( -1 ) ) {
        --currentX;
        render();
    } 
    
}

function goRight() {
    if ( valid( 1 ) ) {
        ++currentX;
        render();
    } 
}

function goDown() {
    if ( valid( 0, 1 ) ) {
        ++currentY;
        render();
    } 
}

function goDrop() {
    while( valid(0, 1) ) {
        ++currentY;
    }
    tick();
    render();
}

function goRotate() {
    if (idShape == 3) return;
    var rotated = rotate( current );
    if ( valid( 0, 0, rotated ) ) {
        current = rotated;
        render();
    } 
}

function move (direction) {
    // 0: up, 1: right, 2: down, 3: left
    switch ( direction ) {
        case 3:
            goLeft();
            break;
        case 1:
            goRight();
            break;
        case 2:
            goDrop();
            break;
        case 0:
            goRotate();
            break;
    }

};

function showPlayBtn() {
    document.getElementById('playbutton').style.display = "block";
    document.getElementById('guideline').style.display = "block";
    document.getElementById('guideline-pc').style.display = "block";
}
function hidePlayBtn() {
    document.getElementById("playbutton").style.display = "none";
    document.getElementById("guideline").style.display = "none";
    document.getElementById("guideline-pc").style.display = "none";
}

// checks if the resulting position of current shape will be feasible
function valid( offsetX, offsetY, newCurrent ) {
    offsetX = offsetX || 0;
    offsetY = offsetY || 0;
    offsetX = currentX + offsetX;
    offsetY = currentY + offsetY;
    newCurrent = newCurrent || current;

    for ( var y = 0; y < 4; ++y ) {
        for ( var x = 0; x < 4; ++x ) {
            if ( newCurrent[ y ][ x ] ) {
                if ( typeof board[ y + offsetY ] == 'undefined'
                  || typeof board[ y + offsetY ][ x + offsetX ] == 'undefined'
                  || board[ y + offsetY ][ x + offsetX ]
                  || x + offsetX < 0
                  || y + offsetY >= ROWS
                  || x + offsetX >= COLS ) {
                    if (offsetY == 0 && freezed) {
                        lose = true; // lose if the current shape is settled at the top most row
                        showPlayBtn();
                    } 
                    return false;
                }
            }
        }
    }
    return true;
}

function playButtonClicked() {
    newGame();
    hidePlayBtn();
}

function newGame() {
    clearAllIntervals();
    intervalRender = setInterval( render, 30 );
    init();
    idShape = Math.floor( Math.random() * shapes.length );
    newShape();
    lose = false;
    interval = setInterval( tick, 400 );
}

function clearAllIntervals(){
    clearInterval( interval );
    clearInterval( intervalRender );
}